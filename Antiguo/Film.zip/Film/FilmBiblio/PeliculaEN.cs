﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace FilmBiblio
{
    public class PeliculaEN
    {

        ///////////
        // Patos //
        ///////////

        private PeliculaCAD peliculaCad;

        /////////////////
        // Propiedades //
        /////////////////
        
        private int id;
        private string titulo { get; set; }
        private string director { get; set; }
        private int ano { get; set; }
        private string sinopsis { get; set; }
        private ArrayList reparto { get; set; }
        private string bandaSonora { get; set; }
        private float puntuacion { get; set; }

        ///////////////
        // Funciones //
        ///////////////

        //Constructor por defecto
        public PeliculaEN() {}

        //Constructor con parámetros que son las propiedades de dicha película
        public PeliculaEN(int pid, string ptitulo, string pdirector, int pano, string psinopsis, string[] preparto, string pbandaSonora)
        {
            id = pid;
            titulo = ptitulo;
            director = pdirector;
            ano = pano;
            sinopsis = psinopsis;

            for (int i = 0; i < preparto.Count()-1;i++)
            {
                reparto[i] = preparto[i];
            }
            
            bandaSonora = pbandaSonora;
        }

        /////////////////
        // Propiedades //
        /////////////////

        //Desde fuera de la clase se puede obtener el id y modificarlo
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        //Desde fuera de la clase se puede obtener la puntuación y modificarla
        public float Puntuacion
        { 
            get { return puntuacion; }
            set { puntuacion = value; }
        }

        //Desde fuera de la clase se puede obtener el título pero no modificarlo
        public String Titulo
        {
            get { return titulo; }
        }

        //Desde fuera de la clase se puede obtener el director y modificarlo
        public String Director
        {
            get { return director; }
            set { director = value; }
        }

        //Desde fuera de la clase se puede obtener el año y modificarlo
        public int Ano
        {
            get { return ano; }
            set { ano = value; }
        }

        //Desde fuera de la clase se puede obtener la descripción de la película y modificarla
        public String Sinopsis
        {
            get { return sinopsis; }
            set { sinopsis = value; }
        }

        //Desde fuera de la clase se puede obtener el reparto de actores y modificarlo
        public ArrayList Reparto
        {
            get { return reparto; }
            set
            {
                for (int i = 0; i < reparto.Count; i++)
                    reparto[i] = value[i];
            }
        }

        //Desde fuera de la clase se puede obtener la banda sonora y modificarla
        public String BandaSonora
        {
            get { return bandaSonora; }
            set { bandaSonora = value; }
        }

        //Se añade en la BD la nueva puntuación en la fila de esta película concreta 
        public void AnyadirPuntuacion(float calificacion)
        {
            peliculaCad.AnyadirPuntuacion(this.id, calificacion);
        }

        //Se añade en la BD un nuevo artista en el reparto de la película
        public void AnyadirArtistaPelicula(string artista)
        {
            reparto.Add(artista);
            peliculaCad.AnyadirArtistaPelicula(this.id, artista);
        }

        //Se elimina en la BD el artista pasado por parámetro en el reparto de la película
        public void EliminarArtistaPelicula(string artista)
        {
            reparto.Remove(artista);
            /*for (int i = 0; i < reparto.Count; i++)
            {
                if (reparto[i] == artista)
                    reparto.RemoveAt(i);
            }*/
            peliculaCad.EliminarArtistaPelicula(this.id, artista);
        }

        //Se inserta en la BD la nueva película cuyos datos están en esta instancia this de PeliculaEN
        public void InsertarPelicula()
        {
            peliculaCad.InsertarPelicula(this);
        }

        //Se modifica en la BD una película cuyos datos están en esta instancia this de PeliculaEN
        public void UpdatePelicula()
        {
            peliculaCad.UpdatePelicula(this);
        }

        //Se borra en la BD una película diferenciada de las demás por su id
        public void BorrarPelicula()
        {
            peliculaCad.BorrarPelicula(this.id);
        }

        //Devuelve la información de todas las películas
        public ArrayList DamePeliculas()
        {
            ArrayList prueba = new ArrayList();
            prueba = peliculaCad.DamePeliculas();
            return prueba;
        }

        //Devuelve la información de la película que tiene como clave primaria el id pasado por parámetro
        public PeliculaEN DamePelicula()
        {
            PeliculaEN prueba = new PeliculaEN();
            prueba = peliculaCad.DamePelicula(this.id);
            return prueba;
        }
        
    }
}
