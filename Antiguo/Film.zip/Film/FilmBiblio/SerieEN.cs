﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace FilmBiblio
{
    
    public class SerieEN
    {
        ///////////
        // Patos //
        ///////////

        private SerieCAD serieCad;

        /////////////////
        // Propiedades //
        /////////////////

        private int id;
        private string titulo { get; set; }
        private string director { get; set; }
        private int ano { get; set; }
        private string sinopsis { get; set; }
        private ArrayList reparto { get; set; }
        private string bandaSonora { get; set; }
        private int puntuacion { get; set; }

        ///////////////
        // Funciones //
        ///////////////

        //Constructor por defecto
        public SerieEN() {}

        //Constructor con parámetros que son las propiedades de dicha serie
        public SerieEN(int pid, string ptitulo, string pdirector, int pano, string psinopsis, string[] preparto, string pbandaSonora)
        {
            id = pid;
            titulo = ptitulo;
            director = pdirector;
            ano = pano;
            sinopsis = psinopsis;

            for (int i = 0; i < preparto.Count();i++)
            {
                reparto[i] = preparto[i];
            }
            
            bandaSonora = pbandaSonora;
        }

        /////////////////
        // Propiedades //
        /////////////////

        //Desde fuera de la clase se puede obtener el id y modificarlo
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        //Desde fuera de la clase se puede obtener el título pero no modificarlo
        public String Titulo
        {
            get { return titulo; }
        }

        //Desde fuera de la clase se puede obtener el director y modificarlo
        public String Director
        {
            get { return director; }
            set { director = value; }
        }

        //Desde fuera de la clase se puede obtener el año y modificarlo
        public int Ano
        {
            get { return ano; }
            set { ano = value; }
        }

        //Desde fuera de la clase se puede obtener la descripción de la serie y modificarla
        public String Sinopsis
        {
            get { return sinopsis; }
            set { sinopsis = value; }
        }

        //Desde fuera de la clase se puede obtener el reparto de actores y modificarlo
        public ArrayList Reparto
        {
            get { return reparto; }
            set
            {
                for (int i = 0; i < reparto.Count; i++)
                    reparto[i] = value[i];
            }
        }

        //Desde fuera de la clase se puede obtener la banda sonora y modificarla
        public String BandaSonora
        {
            get { return bandaSonora; }
            set { bandaSonora = value; }
        }

        //Se añade en la BD la nueva puntuación en la fila de esta serie concreta 
        public void AnyadirPuntuacion(float calificacion)
        {
            //no se le suma aqui los puntos nuevos?
            serieCad.AnyadirPuntuacion(this.id, calificacion);
        }

        //Se añade en la BD un nuevo artista en el reparto de la serie
        public void AnyadirArtistaSerie(string artista)
        {
            reparto.Add(artista);
            serieCad.AnyadirArtistaSerie(this.id, artista);
        }

        //Se elimina en la BD el artista pasado por parámetro en el reparto de la serie
        public void EliminarArtistaSerie(string artista)
        {
            reparto.Remove(artista);
            /*for (int i = 0; i < reparto.Count; i++)
            {
                if (reparto[i] == artista)
                    reparto.RemoveAt(i);
            }*/
            serieCad.EliminarArtistaSerie(this.id, artista);
        }

        //Se inserta en la BD la nueva serie cuyos datos están en esta instancia this de SerieEN
        public void InsertarSerie()
        {
            serieCad.InsertarSerie(this);
        }

        //Se modifica en la BD una serie cuyos datos están en esta instancia this de SerieEN
        public void UpdateSerie()
        {
            serieCad.UpdateSerie(this);
        }

        //Se borra en la BD una serie diferenciada de las demás por su id
        public void BorrarSerie()
        {
            serieCad.BorrarSerie(this.id);
        }

        //Devuelve la información de todas las series
        public ArrayList DameSeries()
        {
            ArrayList prueba = new ArrayList();
            prueba = serieCad.DameSeries();
            return prueba;
        }

        //Devuelve la información de la serie que tiene como clave primaria el id pasado por parámetro
        public SerieEN DameSerie()
        {
            SerieEN prueba = new SerieEN();
            prueba = serieCad.DameSerie(this.id);
            return prueba;
        }
    }
}
