﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//using PeliculaEN;

namespace WebApplication1
{
    public partial class AddEditFilm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       /* protected void Button_anadir(object sender, EventArgs e)
        {
            PeliculaEN pelicula = new PeliculaEN();
            pelicula.Titulo = TextBoxTitulo.Text;
            pelicula.Director = TextBoxDirector.Text;
            pelicula.Ano = TextBoxAno.Text;
            pelicula.Sinopsis = TextBoxAnoSinopsis.text;
            pelicula.Genero = TextBoxGenero.text;
            //pelicula.Reparto = TextBoxAno.Reparto;
            pelicula.BandaSonora = TextBoxBandaSonora.text;
            pelicula.Portada = TextBoxPortada.text;
            pelicula.Caratula = TextBoxCaratula.text;
            pelicula.Trailer = TextBoxTrailer.text;
            pelicula.InsertarCliente();
        }*/
    }
}